-- Actualización para conectar la versión con grupos A/B. Ejecutar una sola vez en Supabase > SQL Editor > New query.
-- No elimina las tablas ni los datos actuales.
alter table public.teams add column if not exists group_name text not null default 'A';
alter table public.matches add column if not exists group_name text;
alter table public.matches alter column home_goals drop not null;
alter table public.matches alter column away_goals drop not null;
-- Los partidos antiguos no pertenecientes al fixture A/B quedan intactos.
-- Si ya existen políticas RLS para teams y matches, se reutilizan.
